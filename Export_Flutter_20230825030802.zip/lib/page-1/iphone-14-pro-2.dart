import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14pro2ZUD (4:3)
        width: double.infinity,
        height: 852*fem,
        decoration: BoxDecoration (
          color: Color(0xffffa13e),
        ),
        child: Stack(
          children: [
            Positioned(
              // randomsymboles8ULH (4:5)
              left: 110*fem,
              top: 79*fem,
              child: Align(
                child: SizedBox(
                  width: 169.07*fem,
                  height: 192.09*fem,
                  child: Image.asset(
                    'assets/page-1/images/random-symboles-8-Q3s.png',
                    width: 169.07*fem,
                    height: 192.09*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // signupNAm (4:12)
              left: 134*fem,
              top: 281*fem,
              child: Align(
                child: SizedBox(
                  width: 123*fem,
                  height: 43*fem,
                  child: Text(
                    'Signup',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 35*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupfkvkFEZ (97j3UHeTo47Ya71C1dFkVK)
              left: 30*fem,
              top: 421*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 78*fem, 0*fem),
                width: 333*fem,
                height: 51*fem,
                decoration: BoxDecoration (
                  color: Color(0xffd9d9d9),
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupqsd3Xxm (97j3eT2CR3ApxUKze1QSd3)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.5*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(9*fem, 5*fem, 10.5*fem, 6*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff285d5e),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Center(
                        // iconmailSZw (4:15)
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-mail-NNV.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // emailaddressZeZ (4:31)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                      child: Text(
                        'Email address',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 25*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffbaacac),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupjycyfxV (97j3kcWbQzhLs2H8xGjycy)
              left: 30*fem,
              top: 495*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 0*fem),
                width: 333*fem,
                height: 51*fem,
                decoration: BoxDecoration (
                  color: Color(0xffd9d9d9),
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupv6boM4d (97j3tmwfDxzF1Uv7RbV6Bo)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(9*fem, 4*fem, 10*fem, 6.46*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff285d5e),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Center(
                        // iconlockfLD (4:25)
                        child: SizedBox(
                          width: 40*fem,
                          height: 40.54*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-lock-iMP.png',
                            width: 40*fem,
                            height: 40.54*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // passwordnvd (4:32)
                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                      child: Text(
                        'Password',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 25*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffbaacac),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupedhxi3b (97j3z787PLMvyuQzWREdhX)
              left: 38*fem,
              top: 579*fem,
              child: Container(
                width: 326.47*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xff285d5e),
                  borderRadius: BorderRadius.circular(20*fem),
                ),
                child: Center(
                  child: Text(
                    'SIGNUP',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 25*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xfffffbfb),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupmwnmBSy (97j39xqfN6mN3H3QuvMwnm)
              left: 28*fem,
              top: 347*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 181*fem, 0*fem),
                width: 333*fem,
                height: 51*fem,
                decoration: BoxDecoration (
                  color: Color(0xffd9d9d9),
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogrouplex552Z (97j3JTbWJuWzZPTh5RLex5)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20.5*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(11*fem, 6*fem, 8.5*fem, 5*fem),
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xff285d5e),
                        borderRadius: BorderRadius.circular(15*fem),
                      ),
                      child: Center(
                        // iconprofilecirclednSm (4:47)
                        child: SizedBox(
                          width: 40*fem,
                          height: 40*fem,
                          child: Image.asset(
                            'assets/page-1/images/icon-profile-circled.png',
                            width: 40*fem,
                            height: 40*fem,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      // name6iM (4:48)
                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                      child: Text(
                        'Name',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 25*ffem,
                          fontWeight: FontWeight.w800,
                          height: 1.2125*ffem/fem,
                          color: Color(0xffbaacac),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // line1REq (4:37)
              left: 49*fem,
              top: 649*fem,
              child: Align(
                child: SizedBox(
                  width: 303*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line2Lch (4:38)
              left: 49*fem,
              top: 670*fem,
              child: Align(
                child: SizedBox(
                  width: 303*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // orGWM (4:39)
              left: 191*fem,
              top: 650*fem,
              child: Align(
                child: SizedBox(
                  width: 19*fem,
                  height: 19*fem,
                  child: Text(
                    'Or',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w800,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroup8zr5NJV (97j46MShfkW8UsJxkE8Zr5)
              left: 105*fem,
              top: 687*fem,
              child: Container(
                width: 183*fem,
                height: 50*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // applogoinspiraton426EV (4:77)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/app-logo-inspiraton-42.png',
                        width: 50*fem,
                        height: 50*fem,
                      ),
                    ),
                    Container(
                      // applogoinspiraton57Qky (4:112)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/app-logo-inspiraton-57.png',
                        width: 50*fem,
                        height: 50*fem,
                      ),
                    ),
                    Container(
                      // applogoinspiraton1647QV (4:134)
                      width: 50*fem,
                      height: 50*fem,
                      child: Image.asset(
                        'assets/page-1/images/app-logo-inspiraton-164.png',
                        width: 50*fem,
                        height: 50*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // alreadyauserlogin3Z3 (4:135)
              left: 122*fem,
              top: 747*fem,
              child: Align(
                child: SizedBox(
                  width: 151*fem,
                  height: 19*fem,
                  child: Text(
                    'Already a user? Login',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w300,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // iconarrowleftcircledM3w (4:140)
              left: 23*fem,
              top: 20*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 35*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/icon-arrow-left-circled.png',
                      width: 35*fem,
                      height: 35*fem,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}