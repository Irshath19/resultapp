import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14pro1LfT (1:3)
        padding: EdgeInsets.fromLTRB(30*fem, 77*fem, 29.53*fem, 121*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffa13e),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // randomsymboles8meH (1:12)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.41*fem, 22.91*fem),
              width: 169.07*fem,
              height: 192.09*fem,
              child: Image.asset(
                'assets/page-1/images/random-symboles-8.png',
                width: 169.07*fem,
                height: 192.09*fem,
              ),
            ),
            Container(
              // loginqu3 (1:13)
              margin: EdgeInsets.fromLTRB(7.53*fem, 0*fem, 0*fem, 47*fem),
              child: Text(
                'Login',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 35*ffem,
                  fontWeight: FontWeight.w800,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroupknhb7bf (97j1TqzV5Y3D6wW5QxKnhb)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.47*fem, 23*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 78*fem, 0*fem),
              width: double.infinity,
              height: 51*fem,
              decoration: BoxDecoration (
                color: Color(0xffd9d9d9),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupkejhC7K (97j1ikjJsgAQJqhyfMKEJh)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.5*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(9*fem, 5*fem, 10.5*fem, 6*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff285d5e),
                      borderRadius: BorderRadius.circular(15*fem),
                    ),
                    child: Center(
                      // iconmailtVw (1:30)
                      child: SizedBox(
                        width: 40*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/icon-mail.png',
                          width: 40*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // emailaddressFzh (1:38)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                    child: Text(
                      'Email address',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w800,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffbaacac),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupumpkxeD (97j1r5rRr4JUXAtguEUMPK)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.47*fem, 23*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 0*fem),
              width: double.infinity,
              height: 51*fem,
              decoration: BoxDecoration (
                color: Color(0xffd9d9d9),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupysmfqxu (97j1yuxiXC8eHykMgNysMf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(9*fem, 4*fem, 10.53*fem, 7*fem),
                    height: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xff285d5e),
                      borderRadius: BorderRadius.circular(15*fem),
                    ),
                    child: Center(
                      // iconlock9ih (1:37)
                      child: SizedBox(
                        width: 39.47*fem,
                        height: 40*fem,
                        child: Image.asset(
                          'assets/page-1/images/icon-lock.png',
                          width: 39.47*fem,
                          height: 40*fem,
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // passwordfS9 (1:39)
                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                    child: Text(
                      'Password',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w800,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffbaacac),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup7q6hyxd (97j26Vc5wSjaAbRdcN7Q6h)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 4*fem, 10*fem),
              width: double.infinity,
              height: 50*fem,
              decoration: BoxDecoration (
                color: Color(0xff285d5e),
                borderRadius: BorderRadius.circular(20*fem),
              ),
              child: Center(
                child: Text(
                  'LOG IN',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w800,
                    height: 1.2125*ffem/fem,
                    color: Color(0xfffffbfb),
                  ),
                ),
              ),
            ),
            Container(
              // forgotpassword2g1 (1:42)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 180.47*fem, 28*fem),
              child: Text(
                'Forgot Password',
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 15*ffem,
                  fontWeight: FontWeight.w800,
                  height: 1.2125*ffem/fem,
                  color: Color(0xce000000),
                ),
              ),
            ),
            Container(
              // autogroupcv53ioj (97j2EKiNcaZjwQHJPWcv53)
              margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 11.47*fem, 25*fem),
              width: double.infinity,
              height: 19*fem,
              child: Center(
                child: Text(
                  'Or',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 15*ffem,
                    fontWeight: FontWeight.w800,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupmccmoaH (97j2QV67EZd2Kmc71tmcCm)
              margin: EdgeInsets.fromLTRB(7*fem, 0*fem, 0*fem, 0*fem),
              width: 326.47*fem,
              height: 50*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff285d5e)),
                borderRadius: BorderRadius.circular(20*fem),
              ),
              child: Center(
                child: Text(
                  'Sign up',
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w800,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff285d5e),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}